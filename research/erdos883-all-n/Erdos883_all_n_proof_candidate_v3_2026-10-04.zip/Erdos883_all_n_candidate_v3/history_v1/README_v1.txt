Erdős 883 全有限范围证明候选 v1
2026年10月4日 UTC

主要文件
Erdos883_all_n_proof_candidate_v1.txt 是完整单文件证明稿。
本稿的命题覆盖每个非负整数 n，以及所有满足密度条件的集合 A，
保证全部奇数长度 3<=L<=n/3+1 的简单互素圈。
证明由显式 n>=2,000,000 的解析部分和覆盖此前每个 n 的精确区间证书组成。

验证状态
数学论证、有限计算、整数舍入及程序实现已经过独立AI辅助审查。
另行实现的验证器也通过了两个有限区间覆盖和分布不等式检查。
这不是外部同行评审或Lean形式化验证，不作首解、原创方法或优先权声明。
方法明确借鉴 Donald Della Pietra 2026年7月27日公开稿中的平滑、
素数签名和Hall构造；其固定版本的主定理只陈述充分大的 n。
本包没有修改旧v4研究文件，也不涉及另一问完全三部图问题的新结果。

REPRODUCTION
Verify every entry in SHA256SUMS.txt before running any checker.
Use a fresh extraction/copy because some scripts regenerate output files.
All proof-affecting comparisons are integer or exact rational arithmetic.
Printed decimals and times are diagnostic only.
Python 3 standard library and a C++17 compiler supporting __int128 suffice.

From this directory:
  python check_interval_cover.py
  python independent_signature_audit.py
  python independent_adaptive_density_audit.py
  python verify_adaptive_tail_lemma.py
  python totient_repair/check_guarded_finite_cdf.py
  g++ -O3 -std=c++17 -Wall -Wextra -Werror adaptive_bridge.cpp -o /tmp/erdos883_bridge
  /tmp/erdos883_bridge 2000000

Independent implementations:
  g++ -O2 -std=c++17 adversarial_audit/independent_small.cpp -o /tmp/erdos883_small_independent
  /tmp/erdos883_small_independent adversarial_audit/small_intervals.txt
  g++ -O2 -std=c++17 adversarial_audit/independent_bridge.cpp -o /tmp/erdos883_bridge_independent
  /tmp/erdos883_bridge_independent adaptive_bridge_2301_2000000_output.txt
  python adversarial_audit/independent_constants.py
  python adversarial_audit/analytic_numeric_guards.py

Expected results
- 71 contiguous passing intervals cover n=6,...,2300
- 84 contiguous passing intervals cover n=2301,...,2,000,000
- n=0,...,5 is vacuous
- the analytic proof handles every n>=2,000,000
- all exact rational profile, moment, adaptive-tail, and numeric guards pass

REJECT lines in adaptive diagnostic logs are wider attempted intervals that
were split into passing intervals. They are not mathematical counterexamples
and leave no gap in the final cover.

AUDIT AND PROVENANCE
adversarial_audit/FINAL_ADVERSARIAL_AUDIT.txt records the separate
mathematical and independently reimplemented computational review.
FINAL_COMPILATION_AUDIT.txt, when present, identifies the exact final
manuscript hash checked against those audited proofs.
COMPILATION_PROVENANCE.json records the extraction boundaries and hashes
of the mathematical source sections used to compile the single manuscript.
Some audit documents also identify precursor component hashes; the complete
current delivery contents are identified by this bundle's SHA256SUMS.txt.
The source citations and exact prior-publication commit appear in the manuscript.
No coordination messages, private notes, executables, or old incomplete
research packages are part of this delivery.
