#!/usr/bin/env python3
"""Check the exact v2-to-v3 editorial changes and rational error margins.
Run from a packaged copy; this checker changes no files.
"""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction as Q
import difflib
root=Path(__file__).resolve().parent.parent
v2=(root/'Erdos883_all_n_proof_candidate_v2.txt').read_bytes()
v3=(root/'Erdos883_all_n_proof_candidate_v3.txt').read_bytes()
assert sha256(v2).hexdigest()=='46100acea5c0e376ab2879549487e14c099c7caf62cb121d3fc22e0585ab1e2b'
assert sha256(v3).hexdigest()=='2bd1f1ecf8c1e1802b28642808a003d0b372cdb55bb2dc97964259de0c4ab50e'
assert len(v2)==32345 and len(v3)==32764
changes=[
 ('Version 2 4 October 2026 UTC','Version 3 4 October 2026 UTC'),
 ('rationals. Displayed decimal approximations in checker output are diagnostic;',
  'rationals. The two decimal expansions of rational error bounds in Part III\nare explicitly diagnostic approximations; their exact rational bounds are\nauthoritative. Displayed decimal approximations in checker output are diagnostic;'),
 ('The first s odd primes are p_1=3,...,p_s; p=p_(s+1).',
  'The first s odd primes are p_1=3,...,p_s; p=p_(s+1).\nFor s=0, set p_0=2. The 0-signature is empty, p=p_1=3, and the tail\nprimes r>p_0 are exactly the odd primes; all endpoint pairs remain odd.'),
 (' E(n)<=972000/47000000=.02068085106382979,',
  ' E(n)<=972000/47000000\n (diagnostic approximation: 972000/47000000 is approximately .02068085106382979),'),
 (' E(n)<=3969000/376000000=.010555851063829787,',
  ' E(n)<=3969000/376000000\n (diagnostic approximation: 3969000/376000000 is approximately .010555851063829787),'),
]
s=v2.decode()
for old,new in changes:
 assert s.count(old)==1
 s=s.replace(old,new,1)
assert s.encode()==v3
for old,new in reversed(changes):
 assert s.count(new)==1
 s=s.replace(new,old,1)
assert s.encode()==v2
section=lambda t:t.split('\nTheorem\n',1)[1].split('\nStatus and attribution\n',1)[0]
assert section(v2.decode())==section(v3.decode())
diff=''.join(difflib.unified_diff(v2.decode().splitlines(True),v3.decode().splitlines(True),fromfile='Erdos883_all_n_proof_candidate_v2.txt',tofile='Erdos883_all_n_proof_candidate_v3.txt'))
assert (root/'REVISION_V2_TO_V3.diff').read_text()==diff
high=Q(972000,47000000);low=Q(3969000,376000000)
assert high==Q(243,11750) and low==Q(3969,376000)
assert Q(29,1000)-high-Q(83,10000)==Q(9,470000)>0
assert Q(119,5000)-low-Q(33,2500)==Q(83,1880000)>0
assert Q('.010555851063829787')<low # hence it is not an upper bound
py=(root/'adaptive_density_probe.py').read_text()
cpp=(root/'adaptive_bridge.cpp').read_text()
assert 'range(3,N+1,2)' in py and 'for s in range(0,' in py
assert 'for p in ps[s:]:' in py and 'for v in range(1,U+1,2):' in py
assert 'for(int i=3;i<=1000;i+=2)' in cpp and 'for(int s=0;s<20;s++)' in cpp
assert 'for(int idx=s;idx<int(ps.size());idx++)' in cpp and 'for(int v=1;v<=U;v+=2)' in cpp
print('PASS exact v2 and v3 source hashes and byte counts')
print('PASS precisely five reversible editorial replacements and matching diff')
print('PASS byte-identical main theorem')
print('PASS exact high residual margin 9/470000 > 0')
print('PASS exact low residual margin 83/1880000 > 0')
print('PASS second diagnostic decimal is not used as an upper bound')
print('PASS inspected source conventions: empty prefix at s=0, tail starts at 3, odd endpoints only')
