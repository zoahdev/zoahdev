#include <algorithm>
#include <bit>
#include <chrono>
#include <cstdint>
#include <iostream>
#include <numeric>
#include <vector>
using U=uint32_t;
U adj[31];
bool dfs(U available, U first_neighbors, int last, int left) {
 if(left==0) return (first_neighbors & (U(1)<<last));
 U choices=available & adj[last];
 if(left==1) choices &= first_neighbors;
 while(choices){int v=__builtin_ctz(choices);choices&=choices-1;
  if(dfs(available&~(U(1)<<v),first_neighbors,v,left-1))return true;
 }
 return false;
}
bool cycle(U A,int len){
 U starts=A;
 while(starts){int v=__builtin_ctz(starts);starts&=starts-1;
   // The smallest vertex on the cycle is v, eliminating redundant starts.
   U available=starts;
   if(__builtin_popcount(available)>=len-1 && dfs(available,adj[v],v,len-1))return true;
 }
 return false;
}
int main(){
 auto start=std::chrono::steady_clock::now(); unsigned long long checked=0,targets=0;
 for(int n=6;n<=30;n++){
  for(int u=1;u<=n;u++){adj[u-1]=0;for(int v=1;v<=n;v++)if(u!=v && std::gcd(u,v)==1)adj[u-1]|=U(1)<<(v-1);}
  int size=n/2+n/3-n/6+1;
  U a=(U(1)<<size)-1,lim=U(1)<<n;unsigned long long count=0;
  while(a<lim){checked++;count++;
   for(int ell=1;ell<=n/6;ell++){targets++;if(!cycle(a,2*ell+1)){std::cout<<"FAIL n="<<n<<" length="<<(2*ell+1)<<" A=";for(int v=0;v<n;v++)if(a>>v&1)std::cout<<v+1<<",";std::cout<<"\n";return 1;}}
   U low=a&-a, inc=a+low;a=(((a^inc)>>2)/low)|inc;
  }
  std::cout<<"PASS n="<<n<<" minimal subsets="<<count<<" target lengths="<<n/6<<"\n";
 }
 std::cout<<"TOTAL subsets="<<checked<<" cycle targets="<<targets<<" seconds="<<std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count()<<"\n";
}
