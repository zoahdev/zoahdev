from fractions import Fraction
from itertools import combinations, permutations
from math import gcd, prod
from time import process_time
start=process_time()
P=(3,5,7,11)
Q=prod(P)
qnum=[]
errors=[]
for s in range(16):
    qnum.append(prod(p-1 for i,p in enumerate(P) if not (s>>i&1)))
    errors.append(Fraction(2)**(3-s.bit_count()))
assert sum(qnum)==Q
assert sum(errors)==Fraction(81,2)
counts=[0]*16
primes=(13,17,19,23,29)
joint={p:[0]*16 for p in primes}
checks=0
for n in range(1,10001):
    if n%2:
        s=sum(1<<i for i,p in enumerate(P) if n%p==0)
        counts[s]+=1
        for p in primes:
            if n%p==0:joint[p][s]+=1
    for s in range(16):
        assert abs(2*Q*counts[s]-qnum[s]*n)<=2*Q*errors[s]
        checks+=1
        for p in primes:
            assert abs(2*Q*p*joint[p][s]-qnum[s]*n)<=2*Q*p*errors[s]
            checks+=1
# Prefix smoothing is order-theoretic: all choices of odd ranks, all feasible b,
# all retained lengths M, all prefixes k, for universes of size at most 12.
prefixchecks=0
for H in range(2,13):
    for mask in range(1<<H):
        selected=[i for i in range(H) if mask>>i&1]
        for M in range(1,len(selected)+1):
            retained=selected[:M]
            b=len(selected)-M # largest feasible b; smaller b weaken the bound
            for k in range(H+1):
                assert sum(i>=k for i in retained)<=max(0,H-k-b)
                prefixchecks+=1
# Verify the exact residue quantities and monotonicity independently.
lastD=lastB=None
for n in range(0,10001):
    m=n//6; r=n%6; f=n//2+n//3-n//6; H=(n+1)//2; M=n//3-n//6+1
    D=n-f+m; B=H-M
    assert D==3*m+(0,1,1,1,1,2)[r]
    assert B==2*m+(-1,0,0,0,0,1)[r]
    assert M>=m+1
    if lastD is not None: assert D>=lastD and B>=lastB
    lastD,lastB=D,B
print('PASS exact signature and signature-plus-tail-prime discrepancies:',checks)
print('PASS arbitrary-order retained-prefix inequalities:',prefixchecks)
print('PASS integer residue and monotonicity identities for n=0..10000')
print('CPU seconds:',process_time()-start)
