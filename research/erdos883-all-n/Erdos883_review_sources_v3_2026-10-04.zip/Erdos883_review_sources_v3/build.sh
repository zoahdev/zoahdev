#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
mkdir -p build
xelatex -interaction=nonstopmode -halt-on-error -output-directory=build manuscript.tex
xelatex -interaction=nonstopmode -halt-on-error -output-directory=build manuscript.tex
printf '\nBuilt build/manuscript.pdf\n'
